/* 
 * File:   semaphore.h
 * Author: aluno
 *
 * Created on 18 de Outubro de 2016, 09:25
 */

#ifndef SEMAPHORE_H
#define	SEMAPHORE_H

#include <semaphore.h>
 
class Semaphore
{
public:
    Semaphore(int i = 1) { sem_init(&sem, 0, i); }
    ~Semaphore() { sem_destroy(&sem); }
 
    void p() { sem_wait(&sem); }
    void v() { sem_post(&sem); }
 
    operator int()
    {
        int ret;
        sem_getvalue(&sem, &ret);
        return ret;
    }
 
private:
    sem_t sem;
};
 
#endif	/* SEMAPHORE_H */

