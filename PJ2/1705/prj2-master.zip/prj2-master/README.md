## **Projeto Programação Concorrente**

 **Professor:** [Arliones Hoeller](http://wiki.sj.ifsc.edu.br/wiki/index.php/Arliones_Hoeller).
 
 **Equipe:** Kauly Rosa Bohm , Gabriel Wagner Gonçalves.

Corrigir problemas de sincronização do código a baixo:
``` c
	#include <iostream>
	#include <fstream>
	#include <uuid/uuid.h>
	#include <unistd.h>
	#include <errno.h> 
	#include "thread.h"
 
	using namespace std;
 
	const int PRODS = 100;
    const int REP = 10;
    const int CONS = 20;
    const int BUF_SIZE = 35;
    Thread * prods[PRODS];
    Thread * cons[CONS];
    uuid_t buffer[BUF_SIZE];
    static int prod_pos = 0;
    static int cons_pos = 0;
    bool finished = false;
    
    int producer(int n)
    {
        cout << "Producer was born!" << endl;
        int rep = REP;
        char fname[36+1];
        while(rep--)
        {
            if(++prod_pos == BUF_SIZE) prod_pos = 0;
            uuid_generate(buffer[prod_pos]);
            uuid_unparse(buffer[prod_pos], fname);

            string name(fname,sizeof(uuid_t)*2 + 4);
            ofstream file(name.c_str());
            file << name;
            file.close();
        }
        exit(REP);
    }
    int consumer(int n)
    {
        cout << "Consumer was born!" << endl;
        char fname[36+1];
        int consumed = 0;
        while(true)
        {
            if(finished) exit(consumed);
            consumed++;
            if(++cons_pos == BUF_SIZE) cons_pos = 0;
            uuid_unparse(buffer[cons_pos], fname);
            {
                ifstream file(fname);
                if(!file.good()) continue;
                string str;
                file >> str;
                cout << "Consumed: " << str << endl;
            }

            if(remove(fname)) cerr << "Error: " << errno << endl;
        }
        exit(consumed);
    }
	int main()
    {
        cout << "Massive Producer x Consumer Problem\n";
        // Create
        for(int i = 0; i < PRODS; i++)
            prods[i] = new Thread(&producer, i);
        for(int i = 0; i < CONS; i++)
            cons[i] = new Thread(&consumer, i);
        // Join
        int status = 0;
        int produced = 0;
        int consumed = 0;
        for(int i = 0; i < PRODS; i++)
        {
            prods[i]->join(&status);
            produced += status;
        }
        finished = true;
        for(int i = 0; i < CONS; i++)
        {
            cons[i]->join(&status);
            consumed += status;
        }
        cout << "Total produced: " << produced << endl;
        cout << "Total consumed: " << consumed << endl;
        return 0;
    }
```
Mais detalhes [aqui](http://wiki.sj.ifsc.edu.br/wiki/index.php/SOP-EngTel_(p%C3%A1gina)).

#### Problemas Encontrados

1. Várias threads acessando as seções críticas ao mesmo tempo.
2. Falta de sincronismo no acesso as seções críticas, problema do buffer limitado.
3. Impossibilidade de encerrar(join) as threads consumidoras.
4. Sincronismo com o sistema de arquivos.
5. O retorno das threads consumidoras não informa corretamente o número de itens consumidos.

#### Soluções Implementadas

1. Utilizamos semaphores para controlar o acesso ao buffer, sendo necessário dois semaphores para cada posição do buffer.
2. As variáveis _prodpos_ e _conspos_ foram utilizadas para controlar o acesso ás várias posições do buffer, sendo incrementadas a cada acesso. Como elas têm o seu valor alterado pelas threads utilizamos mutex para controlar o acesso.
3. No código "original" não temos como saber se todos os itens já foram consumidos para poder dar o join. Acreditamos que seja este o objetivo da váriavel _finished_, porém ao encerrar os produtores geralmente os consumidores ainda estão consumindo. Sendo assim criamos um contador de itens  consumidos, variável _final_, para comparar com o total produzido, caso verdadeiro _abrir_ todos os semaphores e tirar as threads consumidores de seu loop. Também utilizamos a função _sleep()_ após encerrar as threads produtoras, dando um tempo a mais para os consumidores fazer o seu trabalho.
4. No início da função consumidor foi adicionado a função _sync()_ para o diretório não mostrar os itens já excluídos pelo nosso programa.
5. Este problema não foi resolvido, tentamos utilizar o contador de consumidos, porém somátorio do retorno é sempre maior que o número de itens realmente consumidos.  


## Testes


#### Teste 1 - Produtores, consumidores e buffer com os mesmo tamanho.

- Teste realizado com 1 produtor, 1 consumidor e 1 buffer, os dados foram produzidos e todos eles - foram consumidos.
- Teste realizado com 15 produtor, 15 consumidor e 15 buffer, os dados foram produzidos e todos eles foram consumidos.

#### Teste 2 - Produtores, consumidores com o mesmo tamanho e buffer maior.

- Teste realizado com 1 produtor, 1 consumidor e 10 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 1 produtor, 1 consumidor e 15 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 1 produtor, 1 consumidor e 25 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 1 produtor, 1 consumidor e 35 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 1 produtor, 1 consumidor e 45 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 35 produtores, 35 consumidores e 60 buffer, os dados foram produzidos e todos eles foram consumidos.

#### Teste 3 - Produtores, consumidores com o mesmo tamanho e buffer menor.

- Teste realizado com 15 produtores, 15 consumidores e 1 buffer, os dados foram produzidos porém nem todos foram consumidos.
- Teste realizado com 15 produtores, 15 consumidores e 5 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 15 produtores, 15 consumidores e 10 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 35 produtores, 35 consumidores e 10 buffer, os dados foram produzidos e todos eles foram consumidos.

#### Teste 4 - Produtores, buffer com o mesmo tamanho e consumidor variando, hora maior que o produtor e buffer, hora menor que o produtor e buffer.

- Teste realizado com 10 produtores, 35 consumidores e 10 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 50 produtores, 3 consumidores e 50 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 100 produtores, 35 consumidores e 100 buffer, os dados foram produzidos e todos eles foram consumidos.


#### Teste 5 - Consumidores e buffer com o mesmo tamanho e produtor variando, hora maior que o consumidor e buffer, hora menor que o consumidor e buffer.

- Teste realizado com 5 produtores, 30 consumidores e 30 buffer, os dados foram produzidos e todos eles foram consumidos.
- Teste realizado com 15 produtores, 30 consumidores e 30 buffer, os dados foram produzidos e todos eles foram consumidos.






