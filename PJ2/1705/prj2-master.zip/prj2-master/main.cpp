#include <iostream>
#include <fstream>
#include <uuid/uuid.h>
#include <unistd.h>
#include <errno.h>
#include "thread.h"
#include "semaphore.h"
#include "mutex.h"

using namespace std;

const int PRODS = 1;
const int REP = 10;
const int CONS = 1;
const int BUF_SIZE = 1;
int final = 0;

Thread * prods[PRODS];
Thread * cons[CONS];

Semaphore empty[BUF_SIZE];
Semaphore full[BUF_SIZE];
Mutex prodM, consM, finalM;
uuid_t buffer[BUF_SIZE];

static int prod_pos = 0;
static int cons_pos = 0;

bool finished = false;

int producer(int n) {
    cout << "Producer was born!" << endl;
    int pRep = REP;
    char fname[36 + 1];
    int produced = 0;
    while (pRep--) {

        prodM.lock();
            produced = prod_pos;
            if (++prod_pos == BUF_SIZE) prod_pos = 0;
        prodM.unlock();
        empty[produced].p();
            uuid_generate(buffer[produced]);  
        full[produced].v();
        uuid_unparse(buffer[produced], fname);         
        string name(fname, sizeof (uuid_t)*2 + 4); 
        ofstream file(name.c_str()); 
        file << name;
        file.close();

    }

    exit(REP);
}

int consumer(int n) {
    cout << "Consumer was born!" << endl;

    char fname[36 + 1];
    int consumed = 0;
    int ret;
    while (true) {

        
        if (finished) break;
        sync();
        
        consM.lock();
            consumed = cons_pos;
            if (++cons_pos == BUF_SIZE) cons_pos = 0;
        consM.unlock();

        full[consumed].p();
            uuid_unparse(buffer[consumed], fname);
            ret++;
        empty[consumed].v();
        {
            ifstream file(fname);
            if (!file.good()) continue;
            string str;
            file >> str;
            cout << "Consumed: " << consumed << " - " << str << endl;
        }

        if (remove(fname)) cerr << "Error: " << errno << endl;
        finalM.lock();
            final++;
        finalM.unlock();

    }

    exit(ret);
}

int main() {

    for (int i = 0; i < BUF_SIZE; i++) {
        empty[i].p();

    }



    cout << "Massive Producer x Consumer Problem\n";
    cout << "PRODUZIR :" << REP * PRODS << endl;
    // Create
    for (int i = 0; i < PRODS; i++)
        prods[i] = new Thread(&producer, i);
    for (int i = 0; i < CONS; i++)
        cons[i] = new Thread(&consumer, i);

    // Join
    int status = 0;
    int produced = 0;
    int consumedd = 0;
    //produtor
    for (int i = 0; i < PRODS; i++) {
        prods[i]->join(&status);
        produced += status;
    }

    sleep(5); // ESPERARRR QUE ENCERRA O PROGRAMA!!!
    
    if (final == produced) {
        for (int i = 0; i < BUF_SIZE; i++) {
            full[i].v();
            empty[i].v();
        }

        finished = true;
    }

    status = 0;
    //consumidor
    for (int i = 0; i < CONS; i++) {
        cons[i]->join(&status);
        consumedd += status;
    }

    cout << "Total produced: " << produced << endl;
    cout << "Total consumed: " << consumedd << endl;

    return 0;
}